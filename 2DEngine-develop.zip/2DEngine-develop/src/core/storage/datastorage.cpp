#include "datastorage.h"

DataStorage::DataStorage()
{

}
